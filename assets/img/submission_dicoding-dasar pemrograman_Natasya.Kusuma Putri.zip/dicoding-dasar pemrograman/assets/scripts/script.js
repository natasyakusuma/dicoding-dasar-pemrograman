const secondMenu = document.querySelector(".secondMenu");
const lastMenu = document.querySelector(".lastMenu");
const firstMenu = document.querySelector(".firstMenu");
const listsecondMenu = document.querySelectorAll("li");


firstMenu.addEventListener('click', show);
lastMenu.addEventListener('click', close);
listsecondMenu[0].addEventListener('click', close);
listsecondMenu[1].addEventListener('click', close);
listsecondMenu[2].addEventListener('click', close);
listsecondMenu[3].addEventListener('click', close);

function show() {
	secondMenu.style.display = 'flex';
	secondMenu.style.top = '0';
}

function close() {
	secondMenu.style.top = '-100%';
}